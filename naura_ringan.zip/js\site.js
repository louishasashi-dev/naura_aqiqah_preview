(function () {
  var config = window.NAURA_ASSETS || { settings: {}, items: {} };

  function makePlaceholder(slot, item) {
    var placeholder = document.createElement("span");
    placeholder.className = "asset-placeholder";
    placeholder.textContent = item && item.label ? item.label : "Gambar belum tersedia";
    slot.replaceChildren(placeholder);
    slot.classList.add("is-placeholder");
  }

  function renderAssets() {
    document.querySelectorAll("[data-asset]").forEach(function (slot) {
      var key = slot.getAttribute("data-asset");
      var item = config.items[key];

      slot.classList.remove("is-placeholder");
      delete slot.dataset.status;
      delete slot.dataset.verified;

      if (!item) {
        makePlaceholder(slot, null);
        return;
      }

      slot.dataset.status = item.status;
      slot.dataset.verified = String(Boolean(item.verified));

      if (config.settings.usePlaceholders || !item.enabled || !item.src) {
        makePlaceholder(slot, item);
        return;
      }

      var image = document.createElement("img");
      image.src = item.src;
      image.alt = item.alt || "";
      image.loading = slot.closest(".hero") ? "eager" : "lazy";
      image.decoding = "async";
      image.onerror = function () {
        makePlaceholder(slot, item);
      };
      slot.replaceChildren(image);
    });
  }

  function setupNav() {
    var toggle = document.querySelector(".nav-toggle");
    var nav = document.getElementById("site-nav");
    if (!toggle || !nav) return;

    function closeNav() {
      nav.classList.remove("is-open");
      toggle.setAttribute("aria-expanded", "false");
      toggle.setAttribute("aria-label", "Buka menu");
    }

    toggle.addEventListener("click", function () {
      var open = !nav.classList.contains("is-open");
      nav.classList.toggle("is-open", open);
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Tutup menu" : "Buka menu");
    });

    nav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", closeNav);
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") closeNav();
    });
  }

  function setYear() {
    var year = document.getElementById("year");
    if (year) year.textContent = String(new Date().getFullYear());
  }

  renderAssets();
  setupNav();
  setYear();

  window.NauraAssets = {
    apply: renderAssets,
    setPlaceholderMode: function (value) {
      config.settings.usePlaceholders = Boolean(value);
      renderAssets();
    }
  };
})();
